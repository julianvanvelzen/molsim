#include <stdio.h>

// constants
#define MAX_NUMBER_OF_PARTICLES 100
#define MAX_ROWS 10
#define MAX_COLLUMNS 10
#define R_CUT 1

// Structs
typedef struct {
	float x;
	float y;
} Vector;

typedef struct {
	Vector position;
	Vector velocity;
	float  radial_distribution;
} Particle;

typedef struct {
	Particle particles[MAX_NUMBER_OF_PARTICLES];
	int number_of_particles;
} Cell;

// prototypes
void Initialize(void);

// globals
extern double Temperature;
extern Cell Map[MAX_COLLUMNS][MAX_ROWS];

double Temperature;
Cell Map[MAX_COLLUMNS][MAX_ROWS];
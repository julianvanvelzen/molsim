TODO:



Hoe cell lists te implementeren?? two dimensional array of linked list (met rma) --> array
ghost cells / pbc?
welke MPI? openmpi?
hoe computers te verbinden? ssh? science park computers root?



compile: mpicc [file] -o [output]
run: mpirun [options] [file]


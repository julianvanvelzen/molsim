#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "system.h"
#include "ran_uniform.h"

void Initialize (){

  Particle particle;

  particle.position.x = RandomNumber();
  particle.position.y = RandomNumber();
  particle.velocity.x = RandomVelocity(Temperature);
  particle.velocity.y = RandomVelocity(Temperature);

  Map[2][2].particles[2] = particle;

}
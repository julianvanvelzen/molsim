#include <mpi.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "system.h"
#include "ran_uniform.h"


int main(int argc, char** argv) {

  // initialisation
  InitializeRandomNumberGenerator(time(0l));
  int i,j,k;
  int world_rank, world_size;
  int number_of_cycles, number_of_processes;
  int dummy;
  if(argc>3){
    Temperature          = (float)atof(argv[1]);
    number_of_cycles     = atoi(argv[2]);
    number_of_processes  = atoi(argv[3]);
  } else {
    printf("Not enough parameters\n");
    exit(1);
  }

  // Initialize the MPI environment
  MPI_Init(&argc, &argv);

  // Find out rank, size
  MPI_Comm_rank(MPI_COMM_WORLD, &world_rank);
  MPI_Comm_size(MPI_COMM_WORLD, &world_size);


  // master processor 
  if(world_rank==0){
    double startwtime = 0.0;
    double endwtime;
    startwtime = MPI_Wtime();
  
    dummy = (int)sqrt(number_of_processes);



    Initialize();

    for(i = 0; i < number_of_cycles; i++){
      printf("master try %lf\n", Map[2][2].particles[2].position.x );
      // MPI_Bcast(&data, 1, MPI_INT, 0, MPI_COMM_WORLD);
    }
  } else {

    // MPI_Bcast(&data, 1, MPI_INT, 0, MPI_COMM_WORLD);
    // printf("Hello world from rank %d out of %d processors. Data = %d\n", world_rank, world_size, data);

  }


  MPI_Finalize();

}




void InitializeRandomNumberGenerator(double seed);
double RandomNumber(void);
double RandomGaussianNumber(void);
double RandomVelocity(double temperature);
